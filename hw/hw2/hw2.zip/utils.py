"""
COS435: Reinforcement Learning - Homework 2
Shared utilities: GIF recording, plotting, and evaluation metrics.

Students: Do NOT modify this file.
"""

import gymnasium as gym
import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image


# ============================================================
# Rollout Recording
# ============================================================

def make_gif(env_or_name, policy, filename, num_episodes=3, max_steps=1000,
             fps=30):
    """Record rollouts of a policy as an animated GIF.

    Args:
        env_or_name: gymnasium environment instance or string env name
        policy: Policy network with a get_action(obs) method
        filename: Path to save the .gif
        num_episodes: Number of episodes to record
        max_steps: Maximum steps per episode
        fps: Frames per second
    """
    if isinstance(env_or_name, str):
        env = gym.make(env_or_name, render_mode="rgb_array")
    else:
        env = gym.make(env_or_name.spec.id, render_mode="rgb_array")

    frames = []
    for ep in range(num_episodes):
        obs, _ = env.reset(seed=ep)
        for step in range(max_steps):
            frame = env.render()
            frames.append(Image.fromarray(frame))
            with torch.no_grad():
                action, _ = policy.get_action(obs)
            obs, reward, terminated, truncated, _ = env.step(action)
            if terminated or truncated:
                # Capture the final frame
                frame = env.render()
                frames.append(Image.fromarray(frame))
                break
    env.close()

    if frames:
        duration = int(1000 / fps)
        frames[0].save(filename, save_all=True, append_images=frames[1:],
                       duration=duration, loop=0)


def make_best_gif(env_or_name, policy, filename, num_episodes=5,
                  max_steps=1000, fps=30):
    """Record several rollouts and save only the best episode as a GIF.

    Runs num_episodes episodes, tracks the total reward and frames for each,
    and saves only the episode with the highest total reward.

    Args:
        env_or_name: gymnasium environment instance or string env name
        policy: Policy network with a get_action(obs) method
        filename: Path to save the .gif
        num_episodes: Number of episodes to try (best one is saved)
        max_steps: Maximum steps per episode
        fps: Frames per second
    """
    if isinstance(env_or_name, str):
        env = gym.make(env_or_name, render_mode="rgb_array")
    else:
        env = gym.make(env_or_name.spec.id, render_mode="rgb_array")

    best_reward = -float('inf')
    best_frames = []

    for ep in range(num_episodes):
        frames = []
        obs, _ = env.reset(seed=ep)
        total_reward = 0.0
        for step in range(max_steps):
            frame = env.render()
            frames.append(Image.fromarray(frame))
            with torch.no_grad():
                action, _ = policy.get_action(obs)
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += reward
            if terminated or truncated:
                frame = env.render()
                frames.append(Image.fromarray(frame))
                break

        if total_reward > best_reward:
            best_reward = total_reward
            best_frames = frames

    env.close()

    if best_frames:
        duration = int(1000 / fps)
        best_frames[0].save(filename, save_all=True,
                            append_images=best_frames[1:],
                            duration=duration, loop=0)
        print(f"  Best episode reward: {best_reward:.1f}")


# ============================================================
# Evaluation
# ============================================================

def evaluate_policy(env, policy, num_episodes=20, max_steps=1000):
    """Evaluate a policy by running deterministic rollouts.

    Args:
        env: gymnasium environment
        policy: Policy network
        num_episodes: Number of evaluation episodes
        max_steps: Max steps per episode

    Returns:
        mean_reward: Mean total reward across episodes
        rewards: list of total rewards per episode
    """
    rewards = []
    for ep in range(num_episodes):
        obs, _ = env.reset(seed=1000 + ep)
        total_reward = 0.0
        for _ in range(max_steps):
            with torch.no_grad():
                action, _ = policy.get_action(obs)
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += reward
            if terminated or truncated:
                break
        rewards.append(total_reward)
    return np.mean(rewards), rewards


def compute_policy_metrics(env, policy, num_episodes=100, max_steps=1000):
    """Compute detailed evaluation metrics for a trained policy.

    Useful for diagnosing failure modes: high variance indicates unreliable
    landing, low success rate with moderate mean reward suggests the policy
    can slow its descent but crashes on landing.

    Args:
        env: gymnasium environment
        policy: Policy network
        num_episodes: Number of evaluation episodes
        max_steps: Max steps per episode

    Returns:
        dict with keys:
            'mean_reward': Mean total reward
            'std_reward': Std of total rewards (measures policy reliability)
            'min_reward': Worst episode reward
            'max_reward': Best episode reward
            'success_rate': Fraction of episodes with reward > 200
            'crash_rate': Fraction of episodes with reward < -100
            'mean_length': Mean episode length
            'rewards': list of all episode rewards
            'lengths': list of all episode lengths
    """
    rewards = []
    lengths = []
    for ep in range(num_episodes):
        obs, _ = env.reset(seed=2000 + ep)
        total_reward = 0.0
        steps = 0
        for _ in range(max_steps):
            with torch.no_grad():
                action, _ = policy.get_action(obs)
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += reward
            steps += 1
            if terminated or truncated:
                break
        rewards.append(total_reward)
        lengths.append(steps)

    return {
        'mean_reward': np.mean(rewards),
        'std_reward': np.std(rewards),
        'min_reward': np.min(rewards),
        'max_reward': np.max(rewards),
        'success_rate': np.mean([r > 200 for r in rewards]),
        'crash_rate': np.mean([r < -100 for r in rewards]),
        'mean_length': np.mean(lengths),
        'rewards': rewards,
        'lengths': lengths,
    }


# ============================================================
# Plotting
# ============================================================

def plot_training_curves(training_rewards, eval_rewards, title, filename,
                         window=50):
    """Plot evaluation reward curve over training.

    Args:
        training_rewards: list of rewards per episode/iteration (unused,
            kept for backward compatibility)
        eval_rewards: list of (step, mean_reward) tuples
        title: Plot title
        filename: Path to save the figure
        window: unused, kept for backward compatibility
    """
    fig, ax = plt.subplots(figsize=(10, 6))

    # Evaluation rewards
    if eval_rewards:
        eval_steps, eval_means = zip(*eval_rewards)
        ax.plot(eval_steps, eval_means, 'o-', color="darkorange",
                label="Evaluation", markersize=4, linewidth=2)

    ax.set_xlabel("Environment Steps", fontsize=12)
    ax.set_ylabel("Total Reward", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(filename, dpi=150, bbox_inches="tight")
    plt.close()


def plot_reward_comparison(eval_reward_lists, labels, title, filename):
    """Plot evaluation reward curves for multiple algorithms.

    Args:
        eval_reward_lists: list of eval_rewards
                           (each is a list of (step, reward) tuples)
        labels: Algorithm names
        title: Plot title
        filename: Path to save the figure
    """
    fig, ax = plt.subplots(figsize=(10, 6))
    colors = ["steelblue", "darkorange", "green", "red", "purple"]

    for i, (eval_rewards, label) in enumerate(zip(eval_reward_lists, labels)):
        if eval_rewards:
            steps, means = zip(*eval_rewards)
            ax.plot(steps, means, 'o-', color=colors[i % len(colors)],
                    label=label, markersize=4, linewidth=2)

    ax.set_xlabel("Environment Steps", fontsize=12)
    ax.set_ylabel("Mean Evaluation Reward", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.axhline(y=200, color="green", linestyle="--", alpha=0.3,
               label="Success threshold (200)")
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(filename, dpi=150, bbox_inches="tight")
    plt.close()


def plot_eval_ci(all_runs, labels, title, filename):
    """Plot evaluation curves with confidence intervals from multiple seeds.

    Each algorithm has multiple runs (one per seed).  The function
    interpolates all runs to a common step axis and plots the mean curve
    with a +/- 1 std shaded region.

    Args:
        all_runs: list of lists.  ``all_runs[i]`` is a list of eval_rewards
                  (one per seed) for algorithm *i*.  Each eval_rewards is a
                  list of ``(step, reward)`` tuples.
        labels: Algorithm names (same length as *all_runs*).
        title: Plot title.
        filename: Path to save the figure.
    """
    fig, ax = plt.subplots(figsize=(10, 6))
    colors = ["steelblue", "darkorange", "green", "red", "purple"]

    for i, (runs, label) in enumerate(zip(all_runs, labels)):
        # Filter out empty runs
        runs = [r for r in runs if r]
        if not runs:
            continue

        # Build a common step axis (union of all step points, sorted)
        all_steps = sorted(set(s for run in runs for s, _ in run))

        # Interpolate each run onto the common axis
        interp_rewards = []
        for run in runs:
            steps, rews = zip(*run)
            interp = np.interp(all_steps, steps, rews)
            interp_rewards.append(interp)

        interp_rewards = np.array(interp_rewards)      # (num_seeds, num_steps)
        mean = np.mean(interp_rewards, axis=0)
        std = np.std(interp_rewards, axis=0)

        color = colors[i % len(colors)]
        ax.plot(all_steps, mean, '-', color=color, label=label, linewidth=2)
        ax.fill_between(all_steps, mean - std, mean + std,
                        alpha=0.2, color=color)

    ax.set_xlabel("Episodes", fontsize=12)
    ax.set_ylabel("Mean Evaluation Reward", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(filename, dpi=150, bbox_inches="tight")
    plt.close()


def plot_ppo_diagnostics(metrics, title, filename):
    """Plot PPO training diagnostics.

    Four subplots: policy loss, value loss, entropy, clip fraction.

    Args:
        metrics: dict with keys 'policy_loss', 'value_loss', 'entropy',
                 'clip_fraction' (each a list of floats)
        title: Plot title prefix
        filename: Path to save the figure
    """
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))

    panels = [
        ('policy_loss', 'Policy Loss'),
        ('value_loss', 'Value Loss'),
        ('entropy', 'Entropy'),
        ('clip_fraction', 'Clip Fraction'),
    ]

    for ax, (key, label) in zip(axes.flat, panels):
        if key in metrics and metrics[key]:
            ax.plot(metrics[key], linewidth=1.5, color="steelblue")
            ax.set_title(f"{title} \u2014 {label}", fontsize=11)
            ax.set_xlabel("Iteration", fontsize=10)
            ax.set_ylabel(label, fontsize=10)
            ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(filename, dpi=150, bbox_inches="tight")
    plt.close()


def plot_reward_histogram(rewards, title, filename):
    """Plot a histogram of episode rewards for variance analysis.

    Useful for comparing the reliability of REINFORCE vs PPO: a tight
    distribution around high reward means the policy is consistent.

    Args:
        rewards: list of episode rewards
        title: Plot title
        filename: Path to save the figure
    """
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(rewards, bins=30, edgecolor='black', alpha=0.7, color='steelblue')
    ax.axvline(np.mean(rewards), color='red', linestyle='--', linewidth=2,
               label=f'Mean: {np.mean(rewards):.1f}')
    ax.axvline(np.median(rewards), color='orange', linestyle='--', linewidth=2,
               label=f'Median: {np.median(rewards):.1f}')
    ax.set_xlabel("Episode Reward", fontsize=12)
    ax.set_ylabel("Count", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(filename, dpi=150, bbox_inches="tight")
    plt.close()
