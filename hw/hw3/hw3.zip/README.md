# Homework 3: Reward Design

## Setup

```bash
pip install gymnasium stable-baselines3 numpy matplotlib pytest
```

## Files

| File | Description |
|---|---|
| `hw3.py` | **Your code goes here.** Fill in every `TODO`. |
| `plots/` | Directory where comparison plots are saved. |

## Instructions

1. Open `hw3.py` and implement four `RewardShapingWrapper` classes (`RewardShaping1` through `RewardShaping4`), each with a different reward shaping approach. For `RewardShaping1`, follow the instructions in the pdf.
   - The agent trains with your shaped reward but is **evaluated on the true sparse reward** (did the car reach the flag?).

2. Run the full script to train all variants and generate the comparison plot:
   ```bash
   python hw3.py
   ```

3. Inspect the plot and answer the written questions in the pdf.

## What to Submit

- `hw3.py` with all TODOs implemented.
- Generated plot (`plots/reward_shaping_comparison.png`).
- The hw3.pdf generated from a completed hw3.tex (completed of course).
