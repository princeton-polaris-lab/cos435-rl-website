"""
COS435: Reinforcement Learning - Homework 3
Shared utilities: video recording and training log plotting.

Do NOT modify this file.
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def record_video(env, model, filename, num_episodes=5, max_steps=1000):
    """Record a video of the trained policy using gymnasium's RecordVideo.

    Args:
        env: The HopperBackflipEnv (or any gym env)
        model: Trained SB3 model with a predict(obs) method
        filename: Path to save the video (e.g., "videos/backflip.mp4")
        num_episodes: Number of episodes to record
        max_steps: Maximum steps per episode
    """
    import gymnasium as gym
    from gymnasium.wrappers import RecordVideo
    import os

    video_dir = os.path.dirname(filename)
    base_name = os.path.splitext(os.path.basename(filename))[0]

    # Create a fresh env with rgb_array rendering for recording
    record_env = gym.make(
        env.spec.id if hasattr(env, 'spec') and env.spec else "Hopper-v5",
        render_mode="rgb_array",
    )

    # Wrap with RecordVideo
    record_env = RecordVideo(
        record_env,
        video_folder=video_dir,
        name_prefix=base_name,
        episode_trigger=lambda ep: ep < num_episodes,
    )

    for ep in range(num_episodes):
        obs, _ = record_env.reset(seed=ep)
        total_reward = 0.0
        for step in range(max_steps):
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, info = record_env.step(action)
            total_reward += reward
            if terminated or truncated:
                break
        print(f"  Episode {ep+1}: reward = {total_reward:.1f}")

    record_env.close()


def plot_training_log(log_path, filename, window=10):
    """Plot training curves from a Stable-Baselines3 Monitor CSV log.

    Args:
        log_path: Path to the monitor CSV log file
        filename: Path to save the figure
        window: Rolling average window
    """
    import csv

    # Try to read the monitor log
    rewards = []
    try:
        with open(log_path, 'r') as f:
            reader = csv.reader(f)
            # Skip the header comment line (starts with #)
            for row in reader:
                if row and row[0].startswith('#'):
                    continue
                if row and row[0] == 'r':  # header row
                    continue
                if row:
                    try:
                        rewards.append(float(row[0]))
                    except (ValueError, IndexError):
                        continue
    except FileNotFoundError:
        print(f"  Warning: Training log not found at {log_path}")
        print("  Skipping training curve plot.")
        return

    if not rewards:
        print("  Warning: No reward data found in training log.")
        return

    fig, ax = plt.subplots(figsize=(10, 6))

    ax.plot(rewards, alpha=0.3, color='steelblue', label='Episode reward')

    if len(rewards) >= window:
        smoothed = np.convolve(rewards, np.ones(window) / window,
                               mode='valid')
        ax.plot(smoothed, color='darkorange', linewidth=2,
                label=f'Rolling avg (window={window})')

    ax.set_xlabel("Episode", fontsize=12)
    ax.set_ylabel("Total Reward", fontsize=12)
    ax.set_title("Hopper Backflip Training", fontsize=14)
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(filename, dpi=150, bbox_inches="tight")
    plt.close()
