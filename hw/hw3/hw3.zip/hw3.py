"""
COS435: Reinforcement Learning - Homework 3
Reward Design: Sparse Rewards and Reward Shaping

In this assignment you will use stable_baselines3's PPO to train on
MountainCarContinuous-v0 with different reward functions.  You train
with your shaped reward but evaluate on the TRUE sparse reward (did the
car actually reach the flag?).

Install: pip install stable-baselines3 gymnasium

Fill in every section marked with TODO.
Run:  python hw3.py
"""

import os
import argparse
import gymnasium as gym
import numpy as np
from multiprocessing import Pool

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from stable_baselines3 import PPO
from stable_baselines3.common.evaluation import evaluate_policy as sb3_evaluate


# ============================================================
# Sparse Reward Wrapper (provided)
# ============================================================

class SparseMountainCarWrapper(gym.Wrapper):
    """Makes MountainCarContinuous-v0 have sparse reward.

    Only gives +1 reward when the car reaches the flag (position >= 0.45).
    All other rewards are 0.  This is the TRUE reward we care about.
    """

    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)
        sparse_reward = 1.0 if terminated and obs[0] >= 0.45 else 0.0
        return obs, sparse_reward, terminated, truncated, info


# ============================================================
# Part 2: Your Reward Shaping Wrappers (students implement 4)
# ============================================================
#
# Each wrapper wraps a SparseMountainCarWrapper and adds shaping
# on top of the sparse reward.  The agent trains with (sparse + shaping)
# but is EVALUATED on the true sparse reward only.

class RewardShaping1(gym.Wrapper):
    """Reward shaping approach 1.

    TODO: Describe your approach here.
    """

    def __init__(self, env):
        super().__init__(env)
        self.prev_obs = None

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        self.prev_obs = obs.copy()
        return obs, info

    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)
        # TODO: Compute your shaping reward
        shaping_reward = 0.0
        self.prev_obs = obs.copy()
        return obs, reward + shaping_reward, terminated, truncated, info


class RewardShaping2(gym.Wrapper):
    """Reward shaping approach 2.

    TODO: Describe your approach here.
    """

    def __init__(self, env):
        super().__init__(env)
        self.prev_obs = None

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        self.prev_obs = obs.copy()
        return obs, info

    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)
        # TODO: Compute your shaping reward
        shaping_reward = 0.0
        self.prev_obs = obs.copy()
        return obs, reward + shaping_reward, terminated, truncated, info


class RewardShaping3(gym.Wrapper):
    """Reward shaping approach 3.

    TODO: Describe your approach here.
    """

    def __init__(self, env):
        super().__init__(env)
        self.prev_obs = None

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        self.prev_obs = obs.copy()
        return obs, info

    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)
        # TODO: Compute your shaping reward
        shaping_reward = 0.0
        self.prev_obs = obs.copy()
        return obs, reward + shaping_reward, terminated, truncated, info


class RewardShaping4(gym.Wrapper):
    """Reward shaping approach 4.

    TODO: Describe your approach here.
    """

    def __init__(self, env):
        super().__init__(env)
        self.prev_obs = None

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        self.prev_obs = obs.copy()
        return obs, info

    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)
        # TODO: Compute your shaping reward
        shaping_reward = 0.0
        self.prev_obs = obs.copy()
        return obs, reward + shaping_reward, terminated, truncated, info


# ============================================================
# Plotting (provided)
# ============================================================

def plot_eval_ci(all_runs, labels, title, filename):
    """Plot eval curves with +/- 1 std confidence bands."""
    fig, ax = plt.subplots(figsize=(10, 6))
    colors = ["gray", "red", "steelblue", "darkorange", "green",
              "purple", "brown", "pink"]

    for i, (runs, label) in enumerate(zip(all_runs, labels)):
        runs = [r for r in runs if r]
        if not runs:
            continue
        all_steps = sorted(set(s for run in runs for s, _ in run))
        interp = np.array([np.interp(all_steps, *zip(*run)) for run in runs])
        mean, std = interp.mean(0), interp.std(0)
        color = colors[i % len(colors)]
        ax.plot(all_steps, mean, '-', color=color, label=label, linewidth=2)
        ax.fill_between(all_steps, mean - std, mean + std,
                        alpha=0.2, color=color)

    ax.set_xlabel("Timesteps", fontsize=12)
    ax.set_ylabel("True Reward (sparse)", fontsize=12)
    ax.set_title(title, fontsize=14)
    ax.legend(fontsize=11)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(filename, dpi=150, bbox_inches="tight")
    plt.close()


# ============================================================
# Training worker (provided)
# ============================================================

SHAPING_CLASSES = {
    'sparse': None,
    'shaping1': RewardShaping1,
    'shaping2': RewardShaping2,
    'shaping3': RewardShaping3,
    'shaping4': RewardShaping4,
}


def _make_train_env(name):
    """Create the TRAINING env (sparse + optional shaping)."""
    base = SparseMountainCarWrapper(gym.make("MountainCarContinuous-v0"))
    cls = SHAPING_CLASSES[name]
    if cls is None:
        return base
    return cls(base)


def _make_eval_env():
    """Create the EVAL env (always true sparse reward)."""
    return SparseMountainCarWrapper(gym.make("MountainCarContinuous-v0"))


def _train_single(args):
    """Worker: train PPO with shaped reward, evaluate on true sparse reward."""
    seed, env_name, total_timesteps, eval_interval = args
    import torch
    torch.set_num_threads(1)

    train_env = _make_train_env(env_name)
    eval_env = _make_eval_env()
    model = PPO("MlpPolicy", train_env, verbose=0, seed=seed)

    eval_rewards = []
    for step in range(0, total_timesteps, eval_interval):
        model.learn(total_timesteps=eval_interval, reset_num_timesteps=False)
        # Always evaluate on TRUE sparse reward
        mean_rew, _ = sb3_evaluate(model, eval_env, n_eval_episodes=20,
                                   deterministic=True)
        eval_rewards.append((step + eval_interval, mean_rew))

    eval_env.close()
    train_env.close()
    return eval_rewards


# ============================================================
# Main
# ============================================================

if __name__ == "__main__":
    plot_dir = os.path.join(os.path.dirname(__file__), "plots")
    os.makedirs(plot_dir, exist_ok=True)

    parser = argparse.ArgumentParser(
        description="HW3: Reward Design on MountainCarContinuous")
    parser.add_argument('--num-seeds', type=int, default=5)
    parser.add_argument('--num-workers', type=int, default=5)
    parser.add_argument('--total-timesteps', type=int, default=100_000)
    cli_args = parser.parse_args()

    EVAL_INTERVAL = 10_000

    variants = ['sparse', 'shaping1', 'shaping2', 'shaping3', 'shaping4']
    labels = ['Sparse (baseline)', 'Shaping 1', 'Shaping 2',
              'Shaping 3', 'Shaping 4']
    all_results = {}

    for name in variants:
        print(f"\n{'='*60}")
        print(f"  Training: {name}  ({cli_args.num_seeds} seeds)")
        print(f"{'='*60}")
        tasks = [(seed, name, cli_args.total_timesteps, EVAL_INTERVAL)
                 for seed in range(cli_args.num_seeds)]
        with Pool(cli_args.num_workers) as pool:
            results = list(pool.map(_train_single, tasks))
        all_results[name] = results
        final = [r[-1][1] for r in results if r]
        print(f"  Final true eval: {np.mean(final):.2f} +/- {np.std(final):.2f}")

    # Plot: all variants evaluated on TRUE sparse reward
    plot_eval_ci(
        [all_results[v] for v in variants],
        labels,
        f"Reward Shaping Comparison (true reward) \u2014 "
        f"MountainCarContinuous ({cli_args.num_seeds} seeds)",
        os.path.join(plot_dir, "reward_shaping_comparison.png"),
    )
    print(f"\nSaved: plots/reward_shaping_comparison.png")

    print(f"\n{'='*60}")
    print("  Done! Check plots/ for results.")
    print(f"{'='*60}")
